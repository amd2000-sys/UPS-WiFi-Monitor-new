
package id.upswifimonitor

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MonitorService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var alarm: ToneGenerator? = null
    private var disconnectedChecks = 0
    private var alarmRunnable: Runnable? = null

    private val check = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("ups_monitor", MODE_PRIVATE)

            if (!prefs.getBoolean("running", false)) {
                stopSelf()
                return
            }

            val connected = wifiConnected(this@MonitorService)
            val silent = prefs.getBoolean("silent_mode", false)

            if (connected) {
                disconnectedChecks = 0
                stopAlarm()
            } else {
                disconnectedChecks++

                if (!silent) startAlarm()

                if (disconnectedChecks >= 2) {
                    stopAlarm()
                    saveResult()
                    stopSelf()
                    return
                }
            }

            updateNotification()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()

        val channel = NotificationChannel(
            "ups_monitor",
            "Pemantauan UPS",
            NotificationManager.IMPORTANCE_LOW
        )

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)

        startForeground(7, buildNotification())

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "UPSWiFiMonitor::MonitorLock"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {
            wakeLock = null
        }

        handler.post(check)
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        if (intent?.action == ACTION_STOP) {
            stopAlarm()
            saveResult()
            stopSelf()
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, MonitorService::class.java)
            .setAction(ACTION_STOP)

        val pendingStop = PendingIntent.getService(
            this,
            10,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = packageManager.getLaunchIntentForPackage(packageName)

        val pendingOpen = PendingIntent.getActivity(
            this,
            11,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prefs = getSharedPreferences("ups_monitor", MODE_PRIVATE)
        val mode = if (prefs.getBoolean("silent_mode", false)) {
            "Mode Senyap"
        } else {
            "Mode Alarm"
        }

        val status = if (wifiConnected(this)) {
            "WiFi terhubung"
        } else {
            "WiFi terputus, memeriksa..."
        }

        return NotificationCompat.Builder(this, "ups_monitor")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("UPS WiFi Monitor")
            .setContentText("$mode • $status")
            .setOngoing(true)
            .setContentIntent(pendingOpen)
            .addAction(
                android.R.drawable.ic_media_pause,
                "Hentikan Pengujian",
                pendingStop
            )
            .build()
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(7, buildNotification())
    }

    private fun startAlarm() {
        if (alarm != null) return

        try {
            alarm = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            alarmRunnable = object : Runnable {
                override fun run() {
                    val tone = alarm ?: return
                    tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900)
                    handler.postDelayed(this, 1500)
                }
            }
            handler.post(alarmRunnable!!)
        } catch (_: Exception) {
            stopAlarm()
        }
    }

    private fun stopAlarm() {
        alarmRunnable?.let { handler.removeCallbacks(it) }
        alarmRunnable = null
        alarm?.stopTone()
        alarm?.release()
        alarm = null
    }

    private fun saveResult() {
        val prefs = getSharedPreferences("ups_monitor", MODE_PRIVATE)
        if (!prefs.getBoolean("running", false)) return

        val start = prefs.getLong("start", 0L)
        val elapsed = (System.currentTimeMillis() - start).coerceAtLeast(0L)

        val stamp = SimpleDateFormat(
            "dd-MM-yyyy HH:mm:ss",
            Locale("id", "ID")
        ).format(Date(start))

        val row = "$stamp | ${format(elapsed)}"
        val old = prefs.getString("history", "") ?: ""

        prefs.edit()
            .putBoolean("running", false)
            .putLong("lastDuration", elapsed)
            .putString("history", if (old.isBlank()) row else "$row\n$old")
            .apply()
    }

    private fun format(ms: Long): String {
        val s = ms / 1000
        return String.format(
            Locale.US,
            "%02d:%02d:%02d",
            s / 3600,
            (s % 3600) / 60,
            s % 60
        )
    }

    override fun onDestroy() {
        handler.removeCallbacks(check)
        stopAlarm()

        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }

        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "id.upswifimonitor.START"
        const val ACTION_STOP = "id.upswifimonitor.STOP"

        fun wifiConnected(context: Context): Boolean {
            val cm = context.getSystemService(
                Context.CONNECTIVITY_SERVICE
            ) as ConnectivityManager

            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false

            return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        }
    }
}
