
package id.upswifimonitor

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.PowerManager

class MonitorService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var alarm: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var alarmRunnable: Runnable? = null

    private val check = object : Runnable {
        override fun run() {
            val connected = wifiConnected(this@MonitorService)

            if (connected) {
                stopAlarm()
            } else {
                startAlarm()
            }

            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()

        val channel = NotificationChannel(
            "ups_monitor",
            "Pemantauan UPS",
            NotificationManager.IMPORTANCE_LOW
        )

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)

        val notification = Notification.Builder(this, "ups_monitor")
            .setContentTitle("UPS WiFi Monitor aktif")
            .setContentText("Sedang memantau koneksi WiFi router")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true)
            .build()

        startForeground(7, notification)

        try {
            val powerManager =
                getSystemService(Context.POWER_SERVICE) as PowerManager

            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "UPSWiFiMonitor::MonitorLock"
            ).apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
            wakeLock = null
        }

        handler.post(check)
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        return START_STICKY
    }

    private fun startAlarm() {
        if (alarm != null) return

        try {
            alarm = ToneGenerator(
                AudioManager.STREAM_ALARM,
                100
            )

            alarmRunnable = object : Runnable {
                override fun run() {
                    val tone = alarm ?: return

                    tone.startTone(
                        ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD,
                        900
                    )

                    handler.postDelayed(this, 1500)
                }
            }

            handler.post(alarmRunnable!!)
        } catch (e: Exception) {
            stopAlarm()
        }
    }

    private fun stopAlarm() {
        alarmRunnable?.let {
            handler.removeCallbacks(it)
        }
        alarmRunnable = null

        alarm?.stopTone()
        alarm?.release()
        alarm = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(check)
        stopAlarm()

        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (e: Exception) {
        }

        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "id.upswifimonitor.START"

        fun wifiConnected(context: Context): Boolean {
            val cm = context.getSystemService(
                Context.CONNECTIVITY_SERVICE
            ) as ConnectivityManager

            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false

            return caps.hasTransport(
                NetworkCapabilities.TRANSPORT_WIFI
            )
        }
    }
}

