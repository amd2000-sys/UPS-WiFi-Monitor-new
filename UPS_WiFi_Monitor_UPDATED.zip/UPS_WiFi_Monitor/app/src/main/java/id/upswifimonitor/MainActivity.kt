
package id.upswifimonitor

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var timerText: TextView
    private lateinit var statusText: TextView
    private lateinit var averageText: TextView
    private lateinit var historyText: TextView
    private lateinit var alarmButton: Button
    private lateinit var silentButton: Button

    private val prefs by lazy {
        getSharedPreferences("ups_monitor", MODE_PRIVATE)
    }

    private val refreshTask = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refresh()
        handler.post(refreshTask)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(8, 25, 55))
        }

        fun text(value: String, size: Float): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(8, 10, 8, 10)
            }
        }

        root.addView(text("UPS WiFi Monitor", 26f))
        root.addView(text("Pemantau daya cadangan router", 14f))

        statusText = text("Status: Memeriksa WiFi...", 16f)
        root.addView(statusText)

        timerText = text("00:00:00", 42f)
        root.addView(timerText)

        root.addView(text("PILIH MODE PENGUJIAN", 15f))

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        alarmButton = Button(this).apply {
            text = "Mode Alarm"
            setOnClickListener {
                prefs.edit().putBoolean("silent_mode", false).apply()
                updateMode()
            }
        }

        silentButton = Button(this).apply {
            text = "Mode Senyap"
            setOnClickListener {
                prefs.edit().putBoolean("silent_mode", true).apply()
                updateMode()
            }
        }

        modeRow.addView(alarmButton, LinearLayout.LayoutParams(0, -2, 1f))
        modeRow.addView(silentButton, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(modeRow)

        val startButton = Button(this).apply {
            text = "MULAI PENGUJIAN"
            setOnClickListener { startTest() }
        }

        val stopButton = Button(this).apply {
            text = "HENTIKAN PENGUJIAN"
            setOnClickListener { stopTest() }
        }

        root.addView(startButton)
        root.addView(stopButton)

        averageText = text("Rata-rata: 00:00:00", 16f)
        root.addView(averageText)

        root.addView(text("RIWAYAT PENGUJIAN", 18f))

        historyText = text("Belum ada riwayat", 13f).apply {
            gravity = Gravity.START
        }

        val scroll = ScrollView(this)
        scroll.addView(historyText)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        setContentView(root)
        updateMode()
    }

    private fun updateMode() {
        val silent = prefs.getBoolean("silent_mode", false)
        alarmButton.alpha = if (silent) 0.5f else 1f
        silentButton.alpha = if (silent) 1f else 0.5f
    }

    private fun startTest() {
        if (prefs.getBoolean("running", false)) {
            Toast.makeText(this, "Pengujian sedang berjalan", Toast.LENGTH_SHORT).show()
            return
        }

        if (!MonitorService.wifiConnected(this)) {
            Toast.makeText(this, "Hubungkan HP ke WiFi router terlebih dahulu", Toast.LENGTH_LONG).show()
            return
        }

        prefs.edit()
            .putBoolean("running", true)
            .putLong("start", System.currentTimeMillis())
            .apply()

        val intent = Intent(this, MonitorService::class.java)
            .setAction(MonitorService.ACTION_START)

        startForegroundService(intent)
        refresh()
    }

    private fun stopTest() {
        if (!prefs.getBoolean("running", false)) {
            refresh()
            return
        }

        val start = prefs.getLong("start", 0L)
        val elapsed = (System.currentTimeMillis() - start).coerceAtLeast(0L)

        val stamp = SimpleDateFormat(
            "dd-MM-yyyy HH:mm:ss",
            Locale("id", "ID")
        ).format(Date(start))

        val row = "$stamp | ${format(elapsed)}"
        val old = prefs.getString("history", "") ?: ""

        prefs.edit()
            .putBoolean("running", false)
            .putLong("lastDuration", elapsed)
            .putString("history", if (old.isBlank()) row else "$row\n$old")
            .apply()

        stopService(Intent(this, MonitorService::class.java))
        refresh()
    }

    private fun refresh() {
        val running = prefs.getBoolean("running", false)
        val start = prefs.getLong("start", 0L)

        val duration = if (running) {
            System.currentTimeMillis() - start
        } else {
            prefs.getLong("lastDuration", 0L)
        }

        timerText.text = format(duration)

        statusText.text = if (running) {
            if (MonitorService.wifiConnected(this)) {
                "Status: Pengujian berjalan • WiFi terhubung"
            } else {
                "Status: WiFi terputus • Memeriksa..."
            }
        } else {
            if (MonitorService.wifiConnected(this)) {
                "Status: Siap • WiFi terhubung"
            } else {
                "Status: WiFi tidak terhubung"
            }
        }

        val history = prefs.getString("history", "") ?: ""
        historyText.text = if (history.isBlank()) {
            "Belum ada riwayat"
        } else {
            history
        }

        val durations = history.lines().mapNotNull {
            it.substringAfter("|", "").trim().let { value ->
                parseDuration(value)
            }
        }

        val average = if (durations.isNotEmpty()) {
            durations.average().toLong()
        } else {
            0L
        }

        averageText.text = "Rata-rata: ${format(average)}"
        updateMode()
    }

    private fun parseDuration(value: String): Long? {
        return try {
            val parts = value.split(":").map { it.toLong() }
            if (parts.size != 3) return null
            (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000
        } catch (_: Exception) {
            null
        }
    }

    private fun format(ms: Long): String {
        val seconds = ms / 1000
        return String.format(
            Locale.US,
            "%02d:%02d:%02d",
            seconds / 3600,
            (seconds % 3600) / 60,
            seconds % 60
        )
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        super.onDestroy()
    }
}
