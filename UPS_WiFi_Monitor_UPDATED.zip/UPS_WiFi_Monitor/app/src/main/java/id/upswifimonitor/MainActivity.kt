
package id.upswifimonitor

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val prefs by lazy {
        getSharedPreferences("ups_monitor", MODE_PRIVATE)
    }

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var status: TextView
    private lateinit var duration: TextView
    private lateinit var average: TextView
    private lateinit var history: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNotificationPermission()
        buildUi()
        handler.post(tick)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                20
            )
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 34, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFFF3F6FA.toInt())
        }

        fun makeText(
            value: String,
            size: Float,
            color: Int = 0xFF172033.toInt()
        ): TextView {
            return TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                setPadding(4, 10, 4, 10)
            }
        }

        root.addView(makeText("UPS WiFi Monitor", 27f))

        status = makeText("Memeriksa WiFi...", 17f)
        root.addView(status)

        root.addView(
            makeText("DURASI PENGUJIAN", 13f, 0xFF65738A.toInt())
        )

        duration = makeText("00:00:00", 42f)
        root.addView(duration)

        startButton = Button(this).apply {
            text = "MULAI PENGUJIAN"
            setOnClickListener { startTest() }
        }

        stopButton = Button(this).apply {
            text = "SELESAI PENGUJIAN"
            setOnClickListener { stopTest() }
        }

        root.addView(startButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(stopButton, LinearLayout.LayoutParams(-1, -2))

        average = makeText("Rata-rata: belum ada data", 16f)
        root.addView(average)

        root.addView(makeText("RIWAYAT PENGUJIAN", 18f))

        history = makeText("Belum ada pengujian.", 13f)
        root.addView(history)

        val scroll = ScrollView(this).apply {
            addView(root)
        }

        setContentView(scroll)
    }

    private fun startTest() {
        if (prefs.getBoolean("running", false)) return

        prefs.edit()
            .putBoolean("running", true)
            .putLong("start", System.currentTimeMillis())
            .apply()

        val intent = Intent(this, MonitorService::class.java)
            .setAction(MonitorService.ACTION_START)

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }

        refresh()
    }

    private fun stopTest() {
        if (!prefs.getBoolean("running", false)) return

        val start = prefs.getLong("start", 0L)

        val elapsed = (
            System.currentTimeMillis() - start
        ).coerceAtLeast(0L)

        val old = prefs.getString("history", "") ?: ""

        val stamp = SimpleDateFormat(
            "dd-MM-yyyy HH:mm:ss",
            Locale("id", "ID")
        ).format(Date(start))

        val row = "$stamp | ${format(elapsed)}"

        prefs.edit()
            .putBoolean("running", false)
            .putString(
                "history",
                if (old.isBlank()) row else "$row\n$old"
            )
            .apply()

        stopService(Intent(this, MonitorService::class.java))

        refresh()
    }

    private fun refresh() {
        val running = prefs.getBoolean("running", false)
        val start = prefs.getLong("start", 0L)

        duration.text = if (running) {
            format(
                (System.currentTimeMillis() - start)
                    .coerceAtLeast(0L)
            )
        } else {
            "00:00:00"
        }

        status.text = if (MonitorService.wifiConnected(this)) {
            "WiFi: TERHUBUNG"
        } else {
            "WiFi: TERPUTUS / TIDAK DIKETAHUI"
        }

        startButton.isEnabled = !running
        stopButton.isEnabled = running

        val rows = (prefs.getString("history", "") ?: "")
            .lines()
            .filter { it.isNotBlank() }

        val seconds = rows.mapNotNull { line ->
            val value = line.substringAfterLast("|", "")
                .trim()
                .split(":")

            if (value.size == 3) {
                val h = value[0].toLongOrNull() ?: return@mapNotNull null
                val m = value[1].toLongOrNull() ?: return@mapNotNull null
                val s = value[2].toLongOrNull() ?: return@mapNotNull null

                h * 3600 + m * 60 + s
            } else {
                null
            }
        }

        average.text = if (seconds.isEmpty()) {
            "Rata-rata ketahanan: belum ada data"
        } else {
            "Rata-rata: ${format((seconds.average() * 1000).toLong())}\n" +
            "Terlama: ${format((seconds.maxOrNull() ?: 0) * 1000)}\n" +
            "Tersingkat: ${format((seconds.minOrNull() ?: 0) * 1000)}"
        }

        history.text = if (rows.isEmpty()) {
            "Belum ada pengujian."
        } else {
            rows.joinToString("\n")
        }
    }

    private fun format(ms: Long): String {
        val s = ms / 1000

        return String.format(
            Locale.US,
            "%02d:%02d:%02d",
            s / 3600,
            (s % 3600) / 60,
            s % 60
        )
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
