# UPS WiFi Monitor

Proyek Android untuk mengukur lama router tetap aktif saat listrik PLN padam.

## Build APK melalui GitHub (cukup HP Android)
1. Buat repository baru di GitHub.
2. Unggah seluruh ISI ZIP ini (ekstrak ZIP terlebih dahulu di HP, lalu unggah folder/file hasil ekstrak).
3. Buka tab **Actions**. Jika diminta, aktifkan GitHub Actions.
4. Pilih workflow **Build APK**, lalu tekan **Run workflow**.
5. Tunggu sampai selesai. Buka hasil run, bagian **Artifacts**, unduh `UPS-WiFi-Monitor-debug-apk`.
6. Ekstrak artifact ZIP dan pasang file APK di HP.

## Catatan pemantauan
Aplikasi memantau keberadaan jaringan Wi-Fi lokal, bukan akses internet. Gangguan internet saja tidak mengakhiri tes. Jika HP kehilangan Wi-Fi, aplikasi menandainya sebagai koneksi terputus/tidak diketahui; hasil tidak otomatis dihitung sebagai UPS habis. Alarm memberi peringatan agar pengguna memeriksa router dan HP.

Untuk hasil paling akurat, hubungkan HP ke SSID router yang sedang diuji, izinkan notifikasi, dan jangan paksa berhenti aplikasi. Penghemat baterai dari pabrikan dapat membatasi layanan latar belakang.
