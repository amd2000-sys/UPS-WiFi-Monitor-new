plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.upswifimonitor"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.upswifimonitor"
        minSdk = 26
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }
}
