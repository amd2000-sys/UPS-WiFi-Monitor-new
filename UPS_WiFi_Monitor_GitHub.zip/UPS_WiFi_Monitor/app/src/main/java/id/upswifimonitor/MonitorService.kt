package id.upswifimonitor

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper

class MonitorService : Service() {
    private lateinit var connectivity: ConnectivityManager
    private val handler = Handler(Looper.getMainLooper())
    private var alarm: ToneGenerator? = null
    private var wasWifi = true
    private val check = object : Runnable {
        override fun run() {
            val connected = wifiConnected(this@MonitorService)
            if (wasWifi && !connected) startAlarm()
            if (!wasWifi && connected) stopAlarm()
            wasWifi = connected
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        connectivity = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val channel = NotificationChannel("ups_monitor", "Pemantauan UPS", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val notification = Notification.Builder(this, "ups_monitor")
            .setContentTitle("UPS WiFi Monitor aktif")
            .setContentText("Memantau koneksi WiFi lokal router")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true).build()
        startForeground(7, notification)
        wasWifi = wifiConnected(this)
        handler.post(check)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun startAlarm() {
        if (alarm != null) return
        alarm = ToneGenerator(AudioManager.STREAM_ALARM, 100).also { tone ->
            handler.post(object : Runnable {
                override fun run() {
                    if (alarm == null) return
                    tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900)
                    handler.postDelayed(this, 1500)
                }
            })
        }
    }

    private fun stopAlarm() {
        alarm?.stopTone()
        alarm?.release()
        alarm = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopAlarm()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "id.upswifimonitor.START"
        fun wifiConnected(context: Context): Boolean {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        }
    }
}
